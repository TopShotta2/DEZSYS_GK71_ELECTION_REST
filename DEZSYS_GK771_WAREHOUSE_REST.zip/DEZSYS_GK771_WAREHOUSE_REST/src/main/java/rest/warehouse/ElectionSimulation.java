package rest.warehouse;

import rest.model.CountingData;
import rest.model.ElectionData;
import rest.model.VorzugsPerson;

import java.util.ArrayList;

public class ElectionSimulation {
	
	private double getRandomDouble( int inMinimum, int inMaximum ) {

		double number = ( Math.random() * ( (inMaximum-inMinimum) + 1 )) + inMinimum; 
		double rounded = Math.round(number * 100.0) / 100.0; 
		return rounded;
		
	}

	private int getRandomInt( int inMinimum, int inMaximum ) {

		double number = ( Math.random() * ( (inMaximum-inMinimum) + 1 )) + inMinimum; 
		Long rounded = Math.round(number); 
		return rounded.intValue();

	}
	
	public ElectionData getData(String inID ) {

		ElectionData data = new ElectionData();
		data.setRegionID(inID);
		data.setRegionName("Linz Bahnhof");
		data.setRegionAddress("Bahnhofsstrasse 27/9");
		data.setRegionPostalCode("4020");
		data.setFederalState("Austria");

		ArrayList<VorzugsPerson> vP1 = new ArrayList<>();
		vP1.add(new VorzugsPerson("Sandip", 1, getRandomInt(60, 100)));
		vP1.add(new VorzugsPerson("Toma", 2, getRandomInt(20, 80)));

		ArrayList<VorzugsPerson> vP2 = new ArrayList<>();
		vP2.add(new VorzugsPerson("Aran", 1, getRandomInt(60, 100)));
		vP2.add(new VorzugsPerson("Danilo", 2, getRandomInt(20, 80)));

		ArrayList<VorzugsPerson> vP3 = new ArrayList<>();
		vP3.add(new VorzugsPerson("Bernhard", 1, getRandomInt(60, 100)));
		vP3.add(new VorzugsPerson("Marko", 2, getRandomInt(20, 80)));

		ArrayList<VorzugsPerson> vP4 = new ArrayList<>();
		vP4.add(new VorzugsPerson("Abdul", 1, getRandomInt(60, 100)));
		vP4.add(new VorzugsPerson("Mohamed", 2, getRandomInt(20, 80)));

		ArrayList<VorzugsPerson> vP5 = new ArrayList<>();
		vP5.add(new VorzugsPerson("Simon", 1, getRandomInt(60, 100)));
		vP5.add(new VorzugsPerson("Jakob", 2, getRandomInt(20, 80)));

		ArrayList<CountingData> parties = new ArrayList<>();
		parties.add(new CountingData("OEVP", getRandomInt(250, 425),vP1));
		parties.add(new CountingData("SPOE", getRandomInt(250, 425),vP2));
		parties.add(new CountingData("FPOE", getRandomInt(250, 425),vP3));
		parties.add(new CountingData("GRUENE", getRandomInt(250, 425),vP4));
		parties.add(new CountingData("NEOS", getRandomInt(250, 425),vP5));
		data.setcD(parties);

		return data;
		
	}

}
