package rest.model;

public class VorzugsPerson {
    private String vorzugsPersonName;
    private int listenNummer;
    private int amountVorzugsStimmen;

    public VorzugsPerson(String vorzugsPersonName, int listenNummer, int amountVorzugsStimmen) {
        this.vorzugsPersonName = vorzugsPersonName;
        this.listenNummer = listenNummer;
        this.amountVorzugsStimmen = amountVorzugsStimmen;
    }

    public String getVorzugsPersonName() {return vorzugsPersonName;}

    public void setVorzugsPersonName(String vorzugsPersonName) {this.vorzugsPersonName = vorzugsPersonName;}

    public int getListenNummer() {return listenNummer;}

    public void setListenNummer(int listenNummer) {this.listenNummer = listenNummer;}

    public int getAmountVorzugsStimmen() {return amountVorzugsStimmen;}

    public void setAmountVorzugsStimmen(int amountVorzugsStimmen) {this.amountVorzugsStimmen = amountVorzugsStimmen;}

}
