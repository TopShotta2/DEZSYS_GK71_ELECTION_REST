package rest.model;

import java.util.ArrayList;

public class CountingData {
    private String partyID;
    private int amountVotes;
    private ArrayList<VorzugsPerson> vP;


    public CountingData(String partyID, int amountVotes, ArrayList<VorzugsPerson> vP) {
        this.partyID = partyID;
        this.amountVotes = amountVotes;
        this.vP = vP;
    }

    public String getPartyID() {return partyID;}

    public void setPartyID(String partyID) {this.partyID = partyID;}

    public int getAmountVotes() {return amountVotes;}

    public void setAmountVotes(int amountVotes) {this.amountVotes = amountVotes;}

    public ArrayList<VorzugsPerson> getvP() {return vP;}

    public void setvP(ArrayList<VorzugsPerson> vP) {this.vP = vP;}
}
